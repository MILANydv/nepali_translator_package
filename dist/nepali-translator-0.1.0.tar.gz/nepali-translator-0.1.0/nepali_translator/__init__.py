# nepali_translator/__init__.py

from .translator import roman_to_unicode_nepali
